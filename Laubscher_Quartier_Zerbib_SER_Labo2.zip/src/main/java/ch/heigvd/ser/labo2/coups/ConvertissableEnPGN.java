/*
 -----------------------------------------------------------------------------------
 Laboratoire : SER - Laboratoire 2
 Fichier     : ConvertissableEnPGN.java
 Auteur(s)   : Jeremy Zerbib, Guillaume Laubscher, Julien Quartier
 Date        : 14/04/2019
 But         :
 Remarque(s) :
 -----------------------------------------------------------------------------------
*/

package ch.heigvd.ser.labo2.coups;

public interface ConvertissableEnPGN {

    String notationPGN();

}
