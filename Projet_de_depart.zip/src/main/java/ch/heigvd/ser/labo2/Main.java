package ch.heigvd.ser.labo2;

import org.jdom2.*; // Librairie à utiliser !

class Main {

    public static void main(String ... args) {

        // TODO : A implémenter...

    }

}
