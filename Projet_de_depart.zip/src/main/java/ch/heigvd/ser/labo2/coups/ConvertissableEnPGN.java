package ch.heigvd.ser.labo2.coups;

public interface ConvertissableEnPGN {

    String notationPGN();

}
